<?php
define('DEFAULT_VIEW', 'home');//set this to any page to be the default home page
define('BASE_URL', 'http://corsair.cs.iupui.edu:21841/final/');

//database info
define('DB_HOST', 'localhost');
define('DB_USER', 'blrbrown');
define('DB_PASS', 'blrbrown-phpmyadmin');
define('DB_NAME', 'blrbrown_db');
