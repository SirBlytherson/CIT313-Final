<?php
	header('Location: '.BASE_URL.'manager/');
?>