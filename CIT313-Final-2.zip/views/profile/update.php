<?php
	echo $response;
	header('location: '.BASE_URL.'members/profile/');
?>