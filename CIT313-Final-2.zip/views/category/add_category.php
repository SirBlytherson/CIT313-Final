<?php
	//echo $response;
	header('Location: '.BASE_URL.'category/');
?>