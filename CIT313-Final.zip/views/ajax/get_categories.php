<?php
	echo $response;
?>