<?php
	header('Location: '.BASE_URL.'blog/');
?>