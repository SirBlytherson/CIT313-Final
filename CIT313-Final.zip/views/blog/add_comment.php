<?php
	header("location: ".BASE_URL.'blog/post/'.$response);
?>